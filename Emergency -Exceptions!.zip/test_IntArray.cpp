// Projekt		eksempler 2. semester
//
// Fil			eksempel 3_3.cpp
//
// Beskrivelse	eksempel p� dynamisk lagerallokering
//				test-program til klassen IntArray
//
// Forfatter	NVJ
//
// Version		1.0 - 120905 - oprindelig version
// Version      2.0 - 021016 -	changed to C++11, where new throws exception, instead of returning nullptr
//								FRABJ

#include "IntArray.h"
#include "IntArrayExceptions.h"

int main()
{
	try
	{
		IntArray testObj(5);

		testObj.print();

		try
		{
			// Each of these could be given its own try/catch block
			testObj.insertNumber(34, 2);
			testObj.insertNumber(11, 4);
			testObj.insertNumber(120, 7);
		}
		catch (IndexRangeException e)
		{
			e.reportError();
			// We don't exit as this could be OK
		}

		testObj.print();


		try
		{
			testObj.setArraySize(15);
		}
		catch (MemoryAllocationException e)
		{
			e.reportError();
			// We don't exit, as this is could be OK
		}
	
		testObj.print();

		try
		{
			testObj.setArraySize(-5);
		}
		catch (MemoryAllocationException e)
		{
			e.reportError();
			// We don't exit, as this is could be OK
		}

		testObj.print();

		try
		{
			testObj.setArraySize(15);
		}
		catch (MemoryAllocationException e)
		{
			e.reportError();
			// We don't exit, as this is could be OK
		}

		testObj.print();

		try
		{
			testObj.setArraySize(4);
		}
		catch (MemoryAllocationException e)
		{
			e.reportError();
			// We don't exit, as this is could be OK
		}

		testObj.print();

		try
		{
			testObj.setArraySize(400000000);
		}
		catch (MemoryAllocationException e)
		{
			e.reportError();
			// We don't exit, as this is could be OK
		}

		cout << "Size of array is now: " << testObj.getArraySize() << endl;
	}
	catch (MemoryAllocationException e)
	{
		e.reportError();
		// We exit, because we don't get any space for our array called testObj.
		exit(1);
	}


	try
	{
		IntArray bigObj(400000000);
		cout << "Size of array is: " << bigObj.getArraySize() << endl;
	}
	catch (MemoryAllocationException e)
	{
		e.reportError();
		cout << "We were not allowed to allocate 400,000,000 integers, but that's OK :-)" << endl;
	}

	cout << endl;

	return 0;
}